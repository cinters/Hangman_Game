
/**
 * Write a description of class Hangman here.
 *
 * @Daniel Tyree
 * @version (a version number or a date)
 */
public class Hangman
{
    
}
