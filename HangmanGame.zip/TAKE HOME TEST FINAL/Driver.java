import java.util.*;
import java.io.*;
/**
 * Program plays a hangman game with the user
 *
 * @Daniel Tyree
 * @10/21/19
 */
public class Driver
{
    
    public static void main (String args[])throws IOException{
        int wrongCount = 0; 
        List<String> guessedList = new ArrayList<String>();
        boolean goAgain = true;
        
        Scanner input = new Scanner (System.in);
        // gets category
        int category = getCategory(input);
        
        // gets word from file
        String word = getWordFromFile(category);
        
        // turns word to all dashed or stars
        String parsedWord = parseWord(word);
        
        while(goAgain) {
        // draw hangman based on wrong count
        drawHangMan(wrongCount);
        
        // get the guessed letter
        String letter = getGuessedLetter(input);
        
        // 0 = not found in word, 1 = found in word,  2 = already guessed
        int handleLetterResult = handleLetter(word, letter, guessedList);
        if(handleLetterResult != 2){
            guessedList.add(letter);
        }
        if(handleLetterResult == 0) {
            wrongCount++;
        }
        
        // changing star to guessed letter in correct position each time 
        parsedWord = reparseWord(letter, word, parsedWord);
        
        goAgain = continueGame(word, parsedWord, wrongCount);
    }
        if (goAgain == false && wrongCount >= 6){
        System.out.println("You lose");
    }
    else{
        System.out.println("You win");
    }
}

/**
 * displays the catagories that the user can choose from
 * @param input the keyboard scanner
 */
public static int getCategory(Scanner input){
    int choice = 0;
    while (choice < 1 || choice > 5){
    System.out.println("Choose a category: ");
    System.out.println("1. Animals");
    System.out.println("2. Car Makes");
    System.out.println("3. Colors");
    System.out.println("4. Movies");
    System.out.println("5. Sports");
    choice = input.nextInt();
    if (choice < 1 || choice > 5){
        System.out.println("That was not a valid choice, please try again");
    }
}
return choice;
}

/**
 * get a word from the file choosen 
 * @param category category chosen by the user 
 */
public static String getWordFromFile(int category)throws IOException{
    String result = "";
    int r = (int)(Math.random() * ((20-1) + 1)) + 1;
    Scanner fileReader;
    String fileName = null;
    switch (category){
            case 1:
                fileName = "Animals.txt"; 
                break;
                
            case 2: 
                fileName = "Car Makes.txt";
                break;
                
            case 3: 
                fileName = "Colors.txt";
                break;
                
            case 4:
                fileName = "Movies.txt";
                break;
                
            case 5: 
                fileName = "Sports.txt";
                break;
}
fileReader = new Scanner (new File(fileName));
int i = 1; 

while(fileReader.hasNext()){
    String tempWord = fileReader.next();
    if(i == r){
        result = tempWord;
        break;
    }
    i++; 
}
fileReader.close();
return result;
}

/**
 * changes the word to all "*"'s
 * @param word word from the file 
 */
public static String parseWord(String word){
    String result = "";
    for (int i = 0; i < word.length(); i++){
        if(word.charAt(i) == ' '){
            result += ' ';
        }
        else{
            result += "*";
        }
        
    }
    return result;
}

/**
 * draws the hangman picture based on the amount of times a wrong letter was guessed
 * @param wrongCount number for how many times a wrong letter was chosen
 */
public static void drawHangMan(int wrongCount){
    System.out.println("|-------|");

    switch(wrongCount){
        case 0:
        System.out.println("|");
        System.out.println("|");
        System.out.println("|");
        System.out.println("|");
        break;
        case 1:
        System.out.println("|       O");
        System.out.println("|");
        System.out.println("|");
        System.out.println("|");
        break;
        
        case 2:
        System.out.println("|       O");
        System.out.println("|       |");
        System.out.println("|       |");
        System.out.println("|");
        break;
        
        case 3:
        System.out.println("|       O");
        System.out.println("|      /|");
        System.out.println("|       |");
        System.out.println("|        ");
        
        case 4:
        System.out.println("|       O");
        System.out.println("|      /|\\");
        System.out.println("|       |");
        System.out.println("|");
        break;
        
        case 5:
        System.out.println("|       O");
        System.out.println("|      /|\\");
        System.out.println("|       |");
        System.out.println("|      /");
        break;
        
        case 6:
       System.out.println("|       O");
       System.out.println("|      /|\\");
       System.out.println("|       |");
       System.out.println("|      / \\");
    }
    System.out.println("|");
    System.out.println("|_______");
    
}
/**
 * Gets the guessed letter from the user
 * @param input the keyboard scanner 
 */
public static String getGuessedLetter(Scanner input){
    String result;
    System.out.println("Enter your guess");
    result = input.next();
    return result;
}
/**
 * returns 0 = not found in word, 1 = found in word,  2 = already guessed
 * 
 * @param word word taken from the file
 * @param letter letter guessed by the user 
 * @param guessedList list of all the letters guessed by the user
 */
public static int handleLetter(String word, String letter, List<String> guessedList){
    int result;
    for(int i = 0; i < guessedList.size(); i++){
        if(guessedList.get(i) == letter){
            result = 2;
            System.out.println("You have already guessed that");
            return result;
        }
    }
    if (word.contains(letter)){
        result = 1;
    }
    else{
        result = 0;
    }
    return result;
}

/**
 * changing star to guessed letter in correct position each time 
 * 
 * @param letter letter chosen by the user
 * @param word word taken from the file 
 * @param parsedWord word in all "*"'s
 */
public static String reparseWord(String letter, String word, String parsedWord){
    String result = "";
    word = word.toLowerCase();
    letter = letter.toLowerCase();
    for (int i = 0; i < word.length(); i++){
        if(word.charAt(i) == letter.charAt(0)){
             result += letter; 
        }
        else{
            result += parsedWord.charAt(i);
        }
        
    }
    return result;
}
/**
 * determines if the game is over or not 
 * @param word word taken from the file 
 * @param parsedWord word in all "*"
 * @param wrongCount number of times a wrong guess was made
 */
public static boolean continueGame(String word, String parsedWord, int wrongCount){
    boolean result = true;
    if (wrongCount >= 6 || parsedWord == word){
        result = false;
    }
    return result;
}
}